Készítette: Kondor Milán
